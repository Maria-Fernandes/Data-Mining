from pyspark import SparkContext, SparkConf
import json
import sys

path =sys.argv[1];

conf = SparkConf().setAppName("FirstApplication")
sc = SparkContext(conf=conf)

# read json file
data = sc.textFile(path)

# Find total number of users
no_of_users=data.map(lambda user:("user",1)).reduceByKey(lambda a, b: a + b).collect()[0][1]

# Average number of written reviews of all users
total_no_of_reviews=data.map(lambda data: json.loads(data)).map(lambda data:("review",data['review_count'])).reduceByKey(lambda a, b: a + b).collect()[0][1]
average_no_of_reviews=total_no_of_reviews/no_of_users

# Number of distinct user names
no_of_unique_users=data.map(lambda data: json.loads(data)).map(lambda data:(data['name'],1)).groupByKey().count()

# Number of users that joined yelp in the year 2011
users_joined_yelp_in_2011=data.map(lambda data: json.loads(data)).filter(lambda data: '2011' in data['yelping_since']).map(lambda x:("count",1)).reduceByKey(lambda a, b: a + b).collect()[0][1]

# Top 10 popular names and the number of times they appear
top_ten_popular_names=data.map(lambda data: json.loads(data)).map(lambda data:(data['name'],1)).reduceByKey(lambda a, b: a + b).sortBy(lambda x: x[0]).takeOrdered(10, key = lambda x: -x[1])
for i in range(len(top_ten_popular_names)):
    top_ten_popular_names[i]=list(top_ten_popular_names[i])

# Top 10 user ids who have written the most number of reviews
top_ten_id_with_highest_reviews=data.map(lambda data: json.loads(data)).map(lambda data:(data['user_id'],data['review_count'])).sortBy(lambda x: x[0]).takeOrdered(10, key = lambda x: -x[1])
for i in range(len(top_ten_id_with_highest_reviews)):
    top_ten_id_with_highest_reviews[i]=list(top_ten_id_with_highest_reviews[i])

dict={}
dict["total_users"]=no_of_users
dict["avg_reviews"]=average_no_of_reviews
dict["distinct_usernames"]=no_of_unique_users
dict["num_users"]=users_joined_yelp_in_2011
dict["top10_popular_names"]=top_ten_popular_names
dict["top10_most_reviews"]=top_ten_id_with_highest_reviews


output=sys.argv[2]
file = open(output,"w")
file.write(str(dict))
file.close()