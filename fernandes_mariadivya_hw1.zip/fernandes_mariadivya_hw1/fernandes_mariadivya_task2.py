from pyspark import SparkContext, SparkConf
import json
import time
import sys


conf = SparkConf().setAppName("FirstApplication")
sc = SparkContext(conf=conf)
path =sys.argv[1]

dict={}
dict["default"]={}
dict["customised"]={}

# read json file
data = sc.textFile(path)

dict["default"]["n_partition"]=data.getNumPartitions()

def count_in_a_partition(iterator):
  yield sum(1 for _ in iterator)

no_of_items_in_partition=data.mapPartitions(count_in_a_partition).collect()

dict["default"]["n_items"]=no_of_items_in_partition

startTimeQuery = time.time()
# Top 10 user ids who have written the most number of reviews
top_ten_id_with_highest_reviews=data.map(lambda data: json.loads(data)).map(lambda data:(data['user_id'],data['review_count'])).takeOrdered(10, key = lambda x: -x[1])
endTimeQuery = time.time()
runTimeQuery = endTimeQuery - startTimeQuery

dict["default"]["exe_time"]=runTimeQuery

rating_data_raw = sc.textFile(path).repartition(int(sys.argv[3]))
dict["customised"]["n_partition"]=rating_data_raw.getNumPartitions()

no_of_items_in_partition=rating_data_raw.mapPartitions(count_in_a_partition).collect()

dict["customised"]["n_items"]=no_of_items_in_partition

startTimeQuery = time.time()
# Top 10 user ids who have written the most number of reviews
top_ten_id_with_highest_reviews=rating_data_raw.map(lambda data: json.loads(data)).map(lambda data:(data['user_id'],data['review_count'])).takeOrdered(10, key = lambda x: -x[1])
endTimeQuery = time.time()
runTimeQuery = endTimeQuery - startTimeQuery

dict["customised"]["exe_time"]=runTimeQuery
dict["explanation"]="Small dataset results in lesser number of partitions resulting in less IO operations.Hence decreasing number of partitions results in decreasing execution time"

output=sys.argv[2]
file = open(output,"w")
file.write(str(dict))
file.close()




