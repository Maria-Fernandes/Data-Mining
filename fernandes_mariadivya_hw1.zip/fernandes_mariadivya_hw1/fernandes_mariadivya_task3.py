from pyspark import SparkContext, SparkConf
import json
import sys
import time


conf = SparkConf().setAppName("FirstApplication")
sc = SparkContext(conf=conf)

path1 =sys.argv[1];
path2 =sys.argv[2];

data1 = sc.textFile(path1)
data2 = sc.textFile(path2)

review_stars=data1.map(lambda data1: json.loads(data1)).map(lambda data1:(data1['business_id'],data1['stars'])).groupByKey().map(lambda x : (x[0], list(x[1])))
business_stars=data2.map(lambda data2: json.loads(data2)).map(lambda data2:(data2['business_id'],data2['state']))

rdd=review_stars.join(business_stars)

joined_rdd=rdd.map(lambda x : (list(x[1]))).map(lambda x : (x[1],x[0])).reduceByKey(lambda a, b: a + b).map(lambda x : (x[0], sum(x[1])/len(x[1]))).sortBy(lambda x: x[0]).sortBy(lambda x: -x[1]).collect()

output=sys.argv[3];
file = open(output,"w")
file.write("state,stars")
file.write("\n")
for x in joined_rdd:
    file.write(str(x[0]+','+str(x[1])))
    file.write("\n")
file.close()

dict={}
output=sys.argv[4];
file = open(output,"w")

startTimeQuery = time.time()
joined_rdd=rdd.map(lambda x : (list(x[1]))).map(lambda x : (x[1],x[0])).reduceByKey(lambda a, b: a + b).map(lambda x : (x[0], sum(x[1])/len(x[1]))).sortBy(lambda x: x[0]).sortBy(lambda x: -x[1]).collect()[0:5]
endTimeQuery = time.time()
runTimeQuery = endTimeQuery - startTimeQuery
dict["m1"]=runTimeQuery

startTimeQuery = time.time()
joined_rdd=rdd.map(lambda x : (list(x[1]))).map(lambda x : (x[1],x[0])).reduceByKey(lambda a, b: a + b).map(lambda x : (x[0], sum(x[1])/len(x[1]))).sortBy(lambda x: x[0]).takeOrdered(5, key = lambda x: -x[1])
endTimeQuery = time.time()
runTimeQuery = endTimeQuery - startTimeQuery
dict["m2"]=runTimeQuery

dict["explanation"]="Case1: All the data is fetched from different nodes and then the first five items are fetched. Case2: First five data is fetched from one node . Hence the second method takes lesser time "

file.write(str(dict))
file.close()





