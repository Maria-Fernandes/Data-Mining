from pyspark import SparkContext
import time
import sys
from graphframes import *
from pyspark.sql import SQLContext
import os

os.environ["PYSPARK_SUBMIT_ARGS"] = ("--packages graphframes:graphframes:0.6.0-spark2.3-s_2.11 pyspark-shell")

start = time.time()

power_input = sys.argv[1]
output = sys.argv[2]

sc = SparkContext()
sc.setLogLevel("ERROR")
text_rdd = sc.textFile(power_input).map(lambda line: line.split(" "))

#for each source node get a list of the destination nodes
src_listOfNodes = text_rdd.map(lambda row: (row[1], {row[0]})).reduceByKey(lambda x, y: x | y)

#generate all posssible pairs src to destination and destination to source
def get_node_pairs(x):
    src = x[0]
    destinations = list(x[1])
    pairs = []
    for i in range(len(destinations)):
        pair = (src, destinations[i])
        pairs.append((pair, 1))
        pair = (destinations[i], src)
        pairs.append((pair, 1))
    return pairs

#generate the edges
node_pairs = src_listOfNodes.flatMap(get_node_pairs).reduceByKey(lambda x, y: x + y)
edges = node_pairs.map(lambda x: x[0])
edge_collect = edges.collect()

def generate_nodes(x):
    return (x[0][0], x[0][1])


#generate the vertices
node_vertices = node_pairs.flatMap(generate_nodes).distinct().map(lambda x: (x, x))
node_verticess_collect = node_vertices.collect()
sqlContext = SQLContext(sc)

vertices=sqlContext.createDataFrame(node_verticess_collect, ["id", "name"])
edges=sqlContext.createDataFrame(edge_collect, ["src", "dst"])

#parameters edges and vertices
g = GraphFrame(vertices, edges)

result = g.labelPropagation(maxIter=5)
result_rdd = result.rdd
result_rdd = result_rdd.map(lambda x: (x['label'], {x['id']}))
result_rdd = result_rdd.reduceByKey(lambda x, y: x | y)
result_rdd_coll = dict(result_rdd.collect())

file = open(output, "w")

output = []

for i in result_rdd_coll:
    output.append(sorted(result_rdd_coll[i]))
output = sorted(output, key=lambda x: x[0])
output = sorted(output, key=lambda x: len(x))


for i in output:
    file.write(str(i)[1:-1] + "\n")

end = time.time()
print("Duration: " + str(end - start))
