from pyspark import SparkContext
import sys
import time
import queue

def get_bet(graph, vertices):
    betweenness = {}
    for v in vertices:
        q = queue.Queue()
        q.put(v)
        s = []
        depth = {}
        shortest_path = {}
        reverse_tree = {}

        for k in graph.keys():
            depth[k] = -1
            shortest_path[k] = 0
            reverse_tree[k] = []

        depth[v] = 0
        shortest_path[v] = 1

        while not q.empty():
            previous_node = q.get()
            s.append(previous_node)
            for node in graph[previous_node]:
                if depth[node] == -1:
                    depth[node] = depth[previous_node] + 1
                    q.put(node)

                if depth[node] == depth[previous_node] + 1:
                    shortest_path[node] += shortest_path[previous_node]
                    reverse_tree[node] = [previous_node] + reverse_tree[node]

        stack = s
        vertex_credit = {}
        edge_credit = {}
        for k in shortest_path.keys():
            vertex_credit[k] = 1.0

        while len(stack) > 0:
            child = stack.pop()
            for parent in reverse_tree[child]:
                credit = vertex_credit[child] * float(shortest_path[parent])
                credit = credit / shortest_path[child]
                if parent < child:
                    edge_credit[(parent, child)] = (edge_credit[(parent, child)]+ credit) if (parent, child) in edge_credit else credit
                else:
                    edge_credit[(child, parent)] = (edge_credit[(child, parent)] + credit) if (child, parent) in edge_credit else credit

                vertex_credit[parent] += credit

        edge_credits = edge_credit


        for k,v in edge_credits.items():
            betweenness[k]= v if k not in betweenness else ( betweenness[k] + v )

    for k, v in betweenness.items():
        betweenness[k] = v/2.0

    return betweenness

def findCommunities(graph, vertices, betweenness):
    newGraph = graph.copy()
    maxMod = -1.0
    maxCommunity = []
    btw = betweenness.copy()
    numEdges = len(btw)

    while len(btw)>0:
        vertex_left = set(vertices)
        community = []
        while len(vertex_left) > 0:
            vertex=vertex_left.pop()
            q = queue.Queue()
            seen = set()
            component = set()

            q.put(vertex)
            while not q.empty():
                v = q.get()
                seen.add(v)
                component.add(v)
                candidate_node = [node for node in newGraph[v] if node not in seen]
                for node in candidate_node:
                    q.put(node)

            comSet=component
            vertex_left = vertex_left.difference(comSet)
            community.append(list(comSet))

        modularity = 0.0
        for com in community:
            comMod = 0.0
            for i in set(com):
                for j in set(com):
                    if i < j:
                        temp = 1.0 - (float(len(graph[i]) * len(graph[j])) / float(2 * numEdges)) if j in graph[
                            i] else 0.0 - (float(len(graph[i]) * len(graph[j])) / float(2 * numEdges))
                        comMod += temp

            modularity += comMod

        modularity = modularity / (2 * numEdges)

        if modularity > maxMod:
            maxMod = modularity
            maxCommunity = community

        btwMax = max(btw.values())
        deleteEdges = []
        for k,v in btw.items():
            if v==btwMax:
                deleteEdges.append(k)

        for i in deleteEdges:
            if i[1] in newGraph[i[0]]:
                l = list(newGraph[i[0]])
                l.remove(i[1])
                newGraph[i[0]] = l
            if i[0] in newGraph[i[1]]:
                l = list(newGraph[i[1]])
                l.remove(i[0])
                newGraph[i[1]] = l

        btw = get_bet(newGraph, vertices)
    return maxMod, maxCommunity


start = time.time()

sc = SparkContext("local[*]", "HW4_TASK1")
sc.setLogLevel("ERROR")

g = sc.textFile(sys.argv[1]).map(lambda x: x.split(" "))
g = g.flatMap(lambda x: ((x[0],x[1]),(x[1],x[0])))\
    .groupByKey()
g = g.collectAsMap()

bet = get_bet(g, list(g.keys()))
bet_sorted = []

for k,v in bet.items():
    bet_sorted.append((str(k[0]), str(k[1]), v)) if str(k[0])<str(k[1]) else bet_sorted.append((str(k[1]), str(k[0]), v))

bet_sorted.sort(key = lambda x: (-x[2], x[0], x[1]))

file = open(sys.argv[2], "w+")
for i in range(len(bet_sorted)):
    file.write("('"+bet_sorted[i][0]+"', '"+bet_sorted[i][1]+"'), "+str(bet_sorted[i][2])+"\n")
file.close()

mod = findCommunities(g, list(g.keys()), bet)
community=mod[1]
sorted_comm = []
for each_com in community:
    comm_append = []
    for element in each_com:
        comm_append.append(str(element))
    sorted_comm.append(sorted(comm_append))

sorted_comm.sort(key = lambda x: (len(x), x[0]))

file = open(sys.argv[3], "w+")
for i in range(len(sorted_comm)):
    file.write(str(sorted_comm[i]).replace("[", "").replace("]", "")+"\n")
file.close()

end = time.time()
print(end-start)