from pyspark import SparkContext, SparkConf
import time
import sys

start = time.time()
ip_path =sys.argv[3]

conf = SparkConf().setAppName("SecondApplication")
sc = SparkContext(conf=conf)

rdd = sc.textFile(ip_path).map(lambda line: line.split(","))

#remove first line i.e header
first = rdd.first()
rdd = rdd.filter(lambda row: row != first)

case=sys.argv[1]

#generate data based on case
if(case == "1"):
    user_business = rdd.map(lambda data: (data[0], data[1])).groupByKey().mapValues(set).values()
elif(case == "2"):
    user_business = rdd.map(lambda data: (data[1], data[0])).groupByKey().mapValues(set).values()
else:
    print("invalid case number")
    exit(-1)

count=user_business.count()
support=int(sys.argv[2])

def generate_frequent_items(baskets, candidatesItem,support):
    dict = {}
    for candidate in candidatesItem:
        for basket in list(baskets):
            if set(candidate).issubset(basket):
                dict[tuple(sorted(set(candidate)))] = dict.get(tuple(sorted(set(candidate))), 0) + 1

    freq = set()
    for prop in dict:
        if (dict[prop] >= support):
            freq.add(prop)

    freq=sorted(freq)
    return freq

def convert_candidate(buckets, candidates):
    dict = {}
    buckets = list(buckets)
    for candidate in candidates:
        key, candidate = (tuple(sorted([candidate])), [candidate]) if (type(candidate) is str) else (candidate, candidate)
        candidate = set(candidate)
        for basket in buckets:
            if candidate.issubset(basket):
                dict[key] = dict.get(key, 0) + 1

    return dict.items()

def write_to_file(file,output):
    initialLength = len(output[0])
    if (initialLength == 1):
        file.write('(\'' + str(output[0][0]) + '\')')
    elif (initialLength > 1):
        file.write(str(output[0][0]))

    for x in output[1:]:
        if len(x) == initialLength:
            file.write(',(\'' + str(x[0]) + '\')') if len(x) == 1 else file.write(',' + str(x))
        else:
            file.write('\n\n'+str(x))
            initialLength = len(x)

def apriori(baskets, support, count):
    user_business = list(baskets)
    length = len(user_business)
    threshold = float(support) * (float(length) / float(count))

    #Generating single candidate
    dict = {}
    for items in user_business:
        for item in items:
            if (item in dict):
                dict[item] = dict[item] + 1
            else:
                dict[item] = 1

    # Generating frequent single candidate
    result = set()
    for prop in dict:
        if(dict[prop] >= threshold):
            result.add((prop,))

    # Generating frequent pairs
    freq_singles = sorted(result)
    freqList = list()
    freqList.extend(freq_singles)

    length_of_freq_itemset = len(freq_singles)
    pairs = []
    for i in range(length_of_freq_itemset):
        for j in range(i + 1, length_of_freq_itemset):
            pairs.append((freq_singles[i][0], freq_singles[j][0]))

    candidate_doubles = pairs

    frequent_pairs=generate_frequent_items(user_business,candidate_doubles,threshold)
    freqList.extend(frequent_pairs)

    items = frequent_pairs
    length = 3

    #Generating frequent items
    while len(items) != 0:
        generate_candidates = []

        for i in range((len(items) - 1)):
            for j in range(i + 1, len(items)):
                if items[i][0:(length - 2)] == items[j][0:(length - 2)]:
                    generate_candidates.append(tuple(set(items[i]) | set(items[j])))
                else:
                    break
        generate_candidates.sort()
        items = generate_frequent_items(user_business, generate_candidates, threshold)
        items.sort()
        freqList.extend(items)
        length += 1

    return freqList

#Map Reduce Phase 1
#Generate candidates items
phase1 = user_business.mapPartitions(lambda data : apriori(data, support, count)).distinct().collect()
phase1 = sorted(phase1, key=lambda x:(len(x),x))

o_p = sys.argv[4]
file = open(o_p, "w")
file.write("Candidates:\n")
write_to_file(file,phase1)

#Map Reduce Phase 2
#Generate frequent items
phase2 = user_business.mapPartitions(lambda baskets : convert_candidate(baskets, phase1)).reduceByKey(lambda x,y: (x+y)).filter(lambda x: x[1] >= support).map(lambda x: x[0]).sortBy(lambda x:(len(x),x)).collect()
end=time.time()-start

file.write("\n\nFrequent Itemsets:\n")
write_to_file(file,phase2)
print("Duration: ",end)
print("Duration: ",end)
file.close()
