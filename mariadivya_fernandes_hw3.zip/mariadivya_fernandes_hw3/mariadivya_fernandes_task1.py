from pyspark import SparkConf, SparkContext
import time
import sys

start = time.time()
conf = SparkConf().setAppName("ThirdApplication")
sc = SparkContext(conf=conf)

ip_path = sys.argv[1]
case = sys.argv[2].lower()
out_file = sys.argv[3]

# Read the csv file and split
rdd = sc.textFile(ip_path).map(lambda line: line.split(","))

#remove first line i.e header
first = rdd.first()
rdd = rdd.filter(lambda row: row != first)
rdd=rdd.persist()

def gen_band_list(x):
    rows_in_each_band = 2
    index = 0

    bands_list = []
    for b in range(0, int(len(x[1]) / rows_in_each_band)):
        rr = []
        for r in range(0, rows_in_each_band):
            rr.append(x[1][index])
            index += 1
        bands_list.append(((b, tuple(rr)), [x[0]]))
        rr.clear()

    return bands_list


# Create 0/1 Characteristic Matrix
# Generate all distinct users ids
usr = rdd.map(lambda line: line[0]).distinct().collect()
# Generate all distinct business ids
business = rdd.map(lambda line: line[1]).distinct().collect()

# Generate business to user map of values
business_user_map = rdd.map(lambda line: (line[1], [line[0]])).reduceByKey(lambda a, b: a + b).collectAsMap()

dict_of_users = {}

# Generate a dictionary of user ids and their indices
for user in range(0, len(usr)):
    dict_of_users[usr[user]] = user

# Generate a matrix of business id and dictionary of user indices
characteristic_matrix= rdd.map(lambda x: (x[1],[dict_of_users[x[0]]])).reduceByKey(lambda x,y: x+y)

def minhashing(x,a):
    minNum=[]
    for ax in a:
        temp=float('inf')
        for xi in x[1]:
            temp=min(temp,(ax * xi + 1) % len(usr))
        minNum.append(temp)

    return (x[0], minNum)

def generate_twenty_primes():
    primes = []
    for possiblePrime in range(2, 72):
        isPrime = True
        for num in range(2, possiblePrime):
            if possiblePrime % num == 0:
                isPrime = False

        if isPrime:
            primes.append(possiblePrime)

    return primes

# Minhash signitures
random_hash_numbers = generate_twenty_primes()
signature_matrix = characteristic_matrix.map(lambda x: minhashing(x,random_hash_numbers))

def calculate_jaccard_similarity(x):
    jaccard_sim = float(len(set(business_user_map[x[0][0]]).intersection(set(business_user_map[x[0][1]]))) / len(set(business_user_map[x[0][0]]).union(set(business_user_map[x[0][1]]))))
    return (((x[0][0], x[0][1]), jaccard_sim))


def generate_c(x):
    values = []
    bsn_sorted = x[1]
    bsn_sorted.sort()
    [values.append(((bsn_sorted[i], bsn_sorted[j]), 1)) for i in range(0, len(bsn_sorted)) for j in range(i + 1, len(bsn_sorted)) if (j > i)]
    return values

# LSH
if case == "jaccard":
    distinct_candidates = signature_matrix.flatMap(lambda x: gen_band_list(x)).reduceByKey(lambda x, y: x + y).filter(
        lambda x: len(x[1]) > 1).flatMap(lambda x: generate_c(x)).distinct()
    js_rdd1 = distinct_candidates.map(lambda x: calculate_jaccard_similarity(x)).filter(lambda x: x[1] >= 0.5)
    js_rdd = js_rdd1.map(lambda line: (line[0][1], (line[0][0], line[1])))
    js_rdd = js_rdd.sortByKey()
    sorted_js_rdd = js_rdd.map(lambda line: (line[1][0], (line[0], line[1][1]))).sortByKey()
    sorted_js_rdd = sorted_js_rdd.collect()

    # output
    file = open(out_file, 'w')

    file.write("business_id_1, business_id_2, similarity")
    for line in sorted_js_rdd:
        file.write("\n" + line[0] + "," + line[1][0] + "," + str(line[1][1]))

    file.close()

    end = time.time()
    print("Duration: " + str(end - start))

else:
    pass