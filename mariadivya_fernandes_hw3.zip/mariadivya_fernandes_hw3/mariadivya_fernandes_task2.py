from pyspark import SparkContext
import time
from pyspark.mllib.recommendation import ALS, Rating
import math
import sys

start = time.time()

# User CF

def generate(line):
    rr = []
    # Generate (user , business[i]) -> (rating[i],avg rating)
    [rr.append(((line[0][0], line[0][1][i]), (line[1][0][i], line[1][1]))) for i in range(0, len( line[0][1]))]
    return rr


def get_user_rating(line, ratings, map_users_listOfBusinesses, business_listOfUsers):
    N=14

    # calculate COSINE SIMILARITY

    # If the user has not rated the item return a rating of zero for that particular user and business
    if (line[1] not in business_listOfUsers.keys()):
        return ((line[0], line[1]), 0)
    else:
        cosine_similarities = []

        for user in business_listOfUsers[line[1]]:
            num = 0
            cosine_similarity = 0
            ctr = 0
            den2 = 0
            den1 = 0

            for business in set(map_users_listOfBusinesses[line[0]]) & set(map_users_listOfBusinesses[user]):
                if (business != line[1] and ctr < N):
                    num += (float(ratings[(line[0], business)][0]) - (ratings[(line[0], map_users_listOfBusinesses[line[0]][0])][1])) * (float(ratings[(user, business)][0]) - ratings[(user, line[1])][1])
                    den1 += (float(ratings[(line[0], business)][0]) - (ratings[(line[0], map_users_listOfBusinesses[line[0]][0])][1])) * (float(ratings[(line[0], business)][0]) - (ratings[(line[0], map_users_listOfBusinesses[line[0]][0])][1]))
                    den2 += (float(ratings[(user, business)][0]) - ratings[(user, line[1])][1]) * (float(ratings[(user, business)][0]) - ratings[(user, line[1])][1])
                    ctr += 1
                else:
                    pass

            if num != 0:
                cosine_similarity = float(num / math.sqrt(den1 * den2))

            cosine_similarities.append((user, cosine_similarity, ratings[(user, line[1])][1]))

        cosine_similarities.sort(key=lambda line: line[1], reverse=True)

        # calculate WEIGHTED AVERAGE

        count = 0
        num = 0
        den = 0

        for index in cosine_similarities:
            if count < N:
                num += (float(ratings[(index[0], line[1])][0]) - index[2]) * index[1]
                den += abs(index[1])
                count += 1
            else:
                break

        if den == 0:
            return ((line[0], line[1]), 0)
        else:
            return ((line[0], line[1]), (float(ratings[(line[0], map_users_listOfBusinesses[line[0]][0])][1]) + (num / den)))

def User_Cf(train_rdd, test_rdd):

    # Generate user -> list of user ratings
    users_listOfRatings = train_rdd.map(lambda x: (x[0], [float(x[2])]))
    users_listOfRatings=users_listOfRatings.reduceByKey(lambda x, y: x + y)

    # Generate user -> ( list of ratings , average of rating)
    normalized_rating = users_listOfRatings.map(lambda x: (x[0], (x[1], sum(x[1])/len(x[1]))))

    # Generate user -> list of businesses
    users_listOfBusinesses = train_rdd.map(lambda line: (line[0], [line[1]]))
    users_listOfBusinesses=users_listOfBusinesses.reduceByKey(lambda x, y: x + y)

    # Generate (user, list of businesses)  -> ( list of ratings , average of rating)
    users_listOfBusiness_ratings = users_listOfBusinesses.join(normalized_rating)
    users_listOfBusiness_ratings=users_listOfBusiness_ratings.map(lambda x: ((x[0], x[1][0]), (x[1][1][0], x[1][1][1])))

    map_users_listOfBusinesses = users_listOfBusinesses
    map_users_listOfBusinesses=map_users_listOfBusinesses.collectAsMap()

    # Generate map (user , business[i]) -> (rating[i] , avg rating)
    ratings = users_listOfBusiness_ratings.flatMap(lambda x: generate(x))
    mapped_rating=ratings.collectAsMap()

    # Generate business -> list of users
    business_listOfUsers = train_rdd.map(lambda x: (x[1], [x[0]]))
    business_listOfUsers = business_listOfUsers.reduceByKey(lambda x, y: x + y)
    business_listOfUsers = business_listOfUsers.collectAsMap()

    # Generate test pairs
    test_pairs = test_rdd.map(lambda x: (x[0], x[1]))

    predicted_ratings = test_pairs.map(
        lambda line: get_user_rating(line, mapped_rating, map_users_listOfBusinesses, business_listOfUsers))

    # OUTPUT
    file = open(out_file, 'w')

    file.write("user_id, business_id, prediction")
    for line in predicted_ratings.collect():
        file.write("\n"+line[0][0] + "," + line[0][1] + "," + str(line[1]))

    file.close()


def modelbased_cf_recommendation(train_rdd, test_rdd):

    users = sc.union([train_rdd.map(lambda a: a[0]).distinct(), test_rdd.map(lambda a: a[0]).distinct()]).collect()
    businesses = sc.union([train_rdd.map(lambda a: a[1]).distinct(), test_rdd.map(lambda a: a[1]).distinct()]).collect()

    users_dict = {}
    for u in range(0, len(users)):
        users_dict[users[u]] = u

    businesses_dict = {}
    for b in range(0, len(businesses)):
        businesses_dict[businesses[b]] = b

    model = ALS.train(train_rdd.map(lambda x: Rating(int(users_dict[x[0]]), int(businesses_dict[x[1]]), float(x[2]))), 3, 15, 0.1)

    # Evaluate the model on testing data
    testing_data = test_rdd.map(lambda x: Rating(int(users_dict[x[0]]), int(businesses_dict[x[1]]), float(x[2])))
    predictions = model.predictAll(testing_data.map(lambda x: (x[0], x[1])))
    predictions=predictions.map(lambda r: ((r[0], r[1]), r[2]))

    ratesAndPreds = testing_data.map(lambda r: ((r[0], r[1]), r[2])).join(predictions)

    file = open(out_file, 'w')

    file.write("user_id, business_id, prediction")
    for i in ratesAndPreds.collect():
        file.write("\n"+users[i[0][0]] + "," + businesses[i[0][1]] + "," + str(i[1][1]))
    file.close()


# Start
train = sys.argv[1]
test =  sys.argv[2]

sc = SparkContext(appName="task2_hw3")
sc.setLogLevel("ERROR")

# Read the csv file and split
rdd_for_training = sc.textFile(train).map(lambda line: line.split(","))

#remove first line i.e header
first = rdd_for_training.first()
rdd_for_training = rdd_for_training.filter(lambda row: row != first)
rdd_for_training=rdd_for_training.persist()

# Read the csv file and split
rdd_for_testing = sc.textFile(test).map(lambda line: line.split(","))

#remove first line i.e header
first = rdd_for_testing.first()
rdd_for_testing = rdd_for_testing.filter(lambda row: row != first)
rdd_for_testing=rdd_for_testing.persist()

case_id = int(sys.argv[3])
out_file = sys.argv[4]

if case_id == 1:
    modelbased_cf_recommendation(rdd_for_training, rdd_for_testing)
elif case_id == 2:
    User_Cf(rdd_for_training, rdd_for_testing)
else:
    pass
end = time.time()
print("Duration: " + str(end - start))