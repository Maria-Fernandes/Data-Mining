import sys
from pyspark import SparkConf, SparkContext
import time
from pyspark.mllib.recommendation import ALS, MatrixFactorizationModel, Rating
import math
import json

def userBasedCF(train_rdd, test_rdd, business_data_avg):
    businesses_per_user = train_rdd.map(lambda x: (x[0], [x[1]])).reduceByKey(lambda x,y: x+y)
    ratings_per_user = train_rdd.map(lambda x: (x[0], [float(x[2])])).reduceByKey(lambda x,y: x+y)
    # avg_rating_per_user : MAP(USER_ID, (LIST(RATINGS), AVG_RATINGS))
    avg_rating_per_user = ratings_per_user.map(lambda x: (x[0], (x[1], sum(x[1])/len(x[1]))))
    # userwise_business_ratings : MAP: (USER_ID, LIST(BUSINESS_ID), ((LIST(RATINGS), AVG_RATING)))
    userwise_business_ratings = businesses_per_user.join(avg_rating_per_user).map(lambda x: ((x[0],x[1][0]),(x[1][1][0],x[1][1][1])))
    # list_businesses_per_user : MAP: (USER_ID, LIST(BUSINESS_ID))
    list_businesses_per_user = businesses_per_user.collectAsMap()
    # rating_per_user_per_business : MAP: ((USER_ID, BUSINESS_ID), (RATING_ID, AVG_RATING))
    rating_per_user_per_business = userwise_business_ratings.flatMap(lambda x: flat_ratings(x)).collectAsMap()
    users_per_business = train_rdd.map(lambda x: (x[1], [x[0]])).reduceByKey(lambda x,y: x+y).collectAsMap()
    N = 14
    pred_ratings = test_rdd.map(lambda x: (x[0],x[1])).map(lambda x: predict_ratings(x, rating_per_user_per_business, list_businesses_per_user, users_per_business, N, business_data_avg))
    rp = test_rdd.map(lambda x: ((x[0], x[1]), float(x[2]))).join(pred_ratings)
    error = rp.map(lambda r: abs(r[1][0] - r[1][1]))
    error01 = error.filter(lambda x: 0 <= x < 1)
    error12 = error.filter(lambda x: 1 <= x < 2)
    error23 = error.filter(lambda x: 2 <= x < 3)
    error34 = error.filter(lambda x: 3 <= x < 4)
    error4 = error.filter(lambda x: 4 <= x)

    MSE = error.map(lambda x: x**2).mean()
    RMSE = pow(MSE, 0.5)
    print("Error Distribution: ")
    print(">=0 and <1: "+str(error01.count()))
    print(">=1 and <2: "+str(error12.count()))
    print(">=2 and <3: "+str(error23.count()))
    print(">=3 and <4: "+str(error34.count()))
    print(">=4: "+str(error4.count()))
    print("RMSE: "+str(RMSE))
    
    f = open(output_file, 'w')
    write_to_file(f, pred_ratings)

def write_to_file(file_obj, pred_ratings):
    file_obj.write("user_id, business_id, prediction")
    for i in pred_ratings.collect():
        file_obj.write("\n")
        file_obj.write(i[0][0]+","+i[0][1]+","+str(i[1]))
    file_obj.close()



def flat_ratings(x):
    # userwise_business_ratings : MAP: (USER_ID, LIST(BUSINESS_ID), ((LIST(RATINGS), AVG_RATING)))
	rows= []
	for i in range(0,len(x[0][1])):
		row= ((x[0][0], x[0][1][i]),(x[1][0][i],x[1][1]))
		rows.append(row)
    #MAP: ((USER_ID, BUSINESS_ID), (RATING, AVG_RATING))
	return rows

def predict_ratings(x, rating_per_user_per_business, list_businesses_per_user, users_per_business, N, business_data_avg):
    test_user_id = x[0]
    test_business_id = x[1]
    
    businesses_rated = list_businesses_per_user[test_user_id]
    avg_rating_1 = rating_per_user_per_business[(test_user_id,businesses_rated[0])][1]
    
    numerator = 0
    denominator1 = 1
    denominator2 = 1

    if(test_business_id not in users_per_business.keys()):
        # no users rated this business
        return ((x[0],x[1]), 0)
    else : 	
        comman_user_ids = users_per_business[test_business_id]
        similarities = []

        for i in comman_user_ids:
            businesses_rated_by_comman_user= list_businesses_per_user[i]
            co_rated_businesses = set(businesses_rated_by_comman_user) & set(businesses_rated)
            limit = 0
            numerator=0
            denominator1=0
            denominator2=0
            similarity=0

            avg_rating_2 = rating_per_user_per_business[(i,test_business_id)][1]

            for j in co_rated_businesses:
                if(j!=test_business_id and limit < N):
                    rating1= float(rating_per_user_per_business[(test_user_id,j)][0])-avg_rating_1
                    rating2= float(rating_per_user_per_business[(i,j)][0])-avg_rating_2

                    numerator = numerator + rating1*rating2
                    denominator1 = denominator1 + rating1*rating1
                    denominator2 = denominator2 + rating2*rating2
                    limit = limit+1
                elif(limit < N):
                    pass
                else:
                    break
            if(numerator!=0):
                similarity = float(numerator/math.sqrt(denominator1*denominator2))
            similarities.append((i,similarity,avg_rating_2))

        similarities.sort(key=lambda x: x[1], reverse=True)
        weighted_average=0
        num = 0
        den = 0
        count = 0

        for i in similarities:
            if(count<N):
                co_rater= i[0]
                similarities= i[1]
                avg_rating= i[2]

                co_rating= float(rating_per_user_per_business[(co_rater,test_business_id)][0])-avg_rating

                num= num + co_rating*similarities
                den= den + abs(similarities)
                count = count+1
            else:
                break

        if(den==0): 
            return ((x[0],x[1]), business_data_avg[x[1]])
        else :
            rating= float(avg_rating_1) + (num/den)
            score= ((x[0],x[1]),(rating + business_data_avg[x[1]])/2)
            return score

def get_spark_context():
    conf = SparkConf().setAppName("competition").setMaster("local[*]")
    sc = SparkContext(conf=conf)
    sc.setLogLevel("ERROR")
    return sc

if __name__=="__main__":
    start = time.time()
    train_yelp_file = sys.argv[1]
    test_yelp_file = sys.argv[2]
    output_file = sys.argv[3]
    
    sc = get_spark_context()
    
    train_data = sc.textFile(train_yelp_file + "yelp_train.csv")
    train_data = train_data.map(lambda x : x.split(','))
    heading = train_data.first()
    train_rdd = train_data.filter(lambda x: x != heading).persist()

    test_data = sc.textFile(test_yelp_file)
    test_data = test_data.map(lambda x : x.split(','))
    heading = test_data.first()
    test_rdd = test_data.filter(lambda x: x != heading).persist()
    business_json_data = train_yelp_file + "business.json"
    business_data = sc.textFile(business_json_data)
    business_data_avg = business_data.map(lambda  data: json.loads(data)).map(lambda data: (data["business_id"], data["stars"])).collectAsMap()

    userBasedCF(train_rdd, test_rdd, business_data_avg)

    
    end= time.time()
    print("Duration: " + str(end-start))