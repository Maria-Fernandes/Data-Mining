import tweepy
import random
import collections



api_key= "r2fvCzC6iKrw9bXBUCtTXBJUQ"
api_secret= "4JkIM63EQ0szLGTQUUcMxLY7WD8jUFbCoigeohacp0VoOLQ1v3"
access_token= "1162386134745460736-jInXmuUy2zfON1AkkxQx8Zoje7eKj9"
access_secret= "W9Tce1FMKxfwXLzsIGeeVVsZ5H5nTP6WXczSJBiJKoVPI"

sequence_num = 0
auth = tweepy.OAuthHandler(api_key, api_secret)
auth.set_access_token(access_token, access_secret)
twitter_api = tweepy.API(auth)


class MyStreamListener(tweepy.StreamListener):

    def __init__(self):
        super(MyStreamListener, self).__init__()
        self.length = 0
        self.sample = list()
        self.count = collections.Counter()

    def on_status(self, status):
        tags = [tag["text"][1:] for tag in status.entities.get('hashtags')]
        if len(tags) > 0:
            self.length += 1
            if self.length > 150:
                random_val = random.randint(1, self.length)
                if random_val < 150:
                    self.count.update(tags)
                    self.sample.append(status)

                    removed_tags_temp = self.sample.pop(random_val).entities.get('hashtags')
                    removed_tags = [tag["text"][1:] for tag in removed_tags_temp]

                    self.count.subtract(removed_tags)
                    count = 0
                    top5 = {}
                    temp = 0
                    for ele in self.count.most_common():
                        if temp != ele[1]:
                            count += 1
                            temp = ele[1]
                        if count == 6:
                            break
                        top5[ele[1]] = top5.get(ele[1], [])
                        top5[ele[1]].append(ele[0])

                    top3_sorted = sorted(top5.keys(), reverse=True)

                    print("The number of tweets with tags from beginning: ", str(self.length))
                    for i in top3_sorted:
                        for j in sorted(top5[i]):
                            print(j+" : " + str(i))
                    print("\n")
            else:
                self.count.update(tags)
                self.sample.append(status)

    def on_error(self, status_code):
        if status_code == 420:
            return False


myStream = tweepy.Stream(auth=twitter_api.auth, listener=MyStreamListener())
tweets = myStream.sample()
myStream.filter(track=["#"])
