from pyspark import SparkContext
from pyspark.streaming import StreamingContext
import sys
import json
import random
import time

import binascii
from datetime import datetime

false_positive = 0
true_negative = 0

present = set()
bits = []
[bits.append(False) for i in range(200)]

hash= []
for index1 in range(0,10):
	hsh = [random.randint(1,100) for index2 in range(0,2)]
	hash.append(hsh)


f = open(sys.argv[2], "w")
f.write("Time,FPR\n")
f.close()


def func(states):
    global false_positive, true_negative
    for i in states.collect():
        encode_state = int(binascii.hexlify(i[0].encode('utf8')), 16)

        flag = True
        for val in hash:
            index = (val[0] * encode_state + val[1]) % 200
            if not bits[index]:
                bits[index] = True
                flag = False

        if(encode_state not in present or flag==False):
            present.add(encode_state)

        if(flag==False):
            true_negative += 1
        else:
            if encode_state not in present:
                false_positive += 1


    total = true_negative + false_positive
    fpr = 0
    if total != 0:
        fpr = false_positive / float(total)


    file = open(sys.argv[2], "a")
    file.write(str(datetime.fromtimestamp(int(time.time()))) + "," + str(fpr) + "\n")
    file.close()


#You will get a batch of data in spark streaming every 10 seconds
sc = StreamingContext(SparkContext(), 10)
data = sc.socketTextStream("localhost", int(sys.argv[1])).map(json.loads)
states = data.map(lambda x: (x["state"], 1)).reduceByKey(lambda x, y: x+y)
states.foreachRDD(lambda state: func(state))

sc.start()
sc.awaitTermination()
