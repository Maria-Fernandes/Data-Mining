from pyspark import SparkContext
import json
import time
from pyspark.streaming import StreamingContext
import binascii
from datetime import datetime
import sys


start = time.time()
hash = [[11, 2281, 421],
        [913, 67, 6311],
        [17, 23, 6151],
        [181, 251, 7817],
        [41, 443, 6151],
        [14, 29, 769],
        [71, 901, 24593],
        [887, 37, 3079]]


def func(cities):
    estimate = 0
    max = [0]*len(hash)

    for city in cities.collect():
        encode_city = int(binascii.hexlify(city[0].encode('utf8')), 16)

        for i in range(len(hash)):
            to_bin = lambda x, n: format(x, 'b').zfill(n)
            bin_num = str(to_bin((((hash[i][0] * encode_city + hash[i][1]) % hash[i][2]) % 256), 8))

            zeroes = 0
            if(bin_num == "00000000"):
                zeroes = 7
            else:
                for j in range(len(bin_num)-1, -1, -1):
                    if(bin_num[j] == "0") :
                        zeroes += 1
                    else:
                        break

            if max[i] < zeroes:
                max[i] = zeroes


    file = open(sys.argv[2], "a")

    for val in max:
        estimate += 2**val

    file.write(str(datetime.fromtimestamp(int(time.time()))) + "," + str(cities.distinct().count()) + "," + str(estimate/len(hash)) + "\n")
    file.close()

stream_sc = StreamingContext(SparkContext(), 5)
window_data = stream_sc.socketTextStream("localhost", int(sys.argv[1])).window(30, 10)

file = open(sys.argv[2], "w")
file.write("Time,Ground Truth,Estimation\n")
file.close()

window_data.map(json.loads).map(lambda data: (data["city"], 1)).foreachRDD(lambda cities: func(cities))
stream_sc.start()
stream_sc.awaitTermination()
